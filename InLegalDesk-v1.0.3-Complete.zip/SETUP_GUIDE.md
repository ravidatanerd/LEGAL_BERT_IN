# 🚀 InLegalDesk Setup Guide

## 📥 What You Downloaded
Complete InLegalDesk platform with Hybrid BERT+GPT AI architecture for Indian legal research.

## 🎯 Quick Start (Windows)

### Prerequisites:
- Python 3.8+ from https://python.org/downloads/
- Windows 10/11 (64-bit)
- 4GB+ RAM, 2GB+ free disk space

### Option 1: Run from Source (Recommended)
```cmd
REM 1. Open Command Prompt as Administrator
REM 2. Navigate to this extracted folder

REM 3. Setup Backend
cd backend
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
copy .env.sample .env
REM IMPORTANT: Edit .env file and add your OpenAI API key for full features
python app.py

REM 4. Setup Desktop (NEW Command Prompt window)
cd desktop
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
xcopy /E /I ..\backend server
python main.py
```

### Option 2: Build Windows Installer
```cmd
REM Run this to create a professional installer:
build_windows_installer.bat
REM Creates: installer\output\InLegalDesk_Installer.exe
```

## 🔑 Configure API Key
1. Launch the desktop app
2. Click "🔑 API Credentials"
3. Enter your OpenAI API key from https://platform.openai.com/api-keys
4. Set a master password
5. Test connection and save

## ✨ Features
- 🤖 Hybrid BERT+GPT AI (InLegalBERT + T5 + XLNet + OpenAI)
- ⚖️ Indian legal research (IPC, CrPC, Evidence Act)
- 💬 ChatGPT-style interface
- 🔒 Secure credential management
- 📄 OCR-free PDF processing
- 🌐 English + Hindi support

## 📞 Support
- Repository: https://github.com/ravidatanerd/LEGAL_BERT_IN
- Issues: https://github.com/ravidatanerd/LEGAL_BERT_IN/issues
- Documentation: See README.md and other guides

## ⚠️ Note
This is for research/educational use. Consult legal professionals for official advice.
